#include <stdio.h>
#define maxsize 100
#define N 4
typedef int Elemtype;

typedef struct{
    int row;
    int col;
    Elemtype num;
}TUPLE;

typedef struct {
    int rows;
    int cols;
    int count;
     TUPLE data[maxsize];
}TSMatrix;

void createmat(TSMatrix &t,Elemtype A[N][N]){
    int i,j;
    t.rows=N;
    t.cols=N;
    t.count=0;
    for(i=0;i<N;i++){
        for(j=0;j<N;j++){
            if(A[i][j]!=0){
                t.data[t.count].row=i;
                t.data[t.count].col=j;
                t.data[t.count].num=A[i][j];
                t.count++;
            }
        }
    }
}

void transmat(TSMatrix t,TSMatrix &t1){
    int p,q=0,v;
    t1.cols=t.cols;
    t1.rows=t.rows;
    t1.count=t.count;
    if(t.count!=0){
    for(v=0;v<t.cols;v++){
        for(p=0;p<t.count;p++){
            if(t.data[p].col==v){
                t1.data[q].col=t.data[p].row;
                t1.data[q].row=t.data[p].col;
                t1.data[q].num=t.data[p].num;
                q++;
            }
        }
    }
}
}

bool addmat(TSMatrix a,TSMatrix b,TSMatrix &c){
    int i=0,j=0,k=0;//iΪ����a�ڷ���Ԫ��������jΪ����b�ڷ���Ԫ������
    Elemtype v;
    if(a.rows!=b.rows||a.cols!=b.cols)
    return false;
    c.cols=a.cols;
    c.rows=a.rows;
    while(i<a.count&&j<b.count){
        if(a.data[i].row==b.data[j].row){
            if(a.data[i].col<b.data[j].col){
                c.data[k].num=a.data[i].num;
                c.data[k].col=a.data[i].col;
                c.data[k].row=a.data[i].row;
                k++;
                i++;
            }
            else if(a.data[i].col>b.data[j].col){
                 c.data[k].num=b.data[i].num;
                c.data[k].col=b.data[i].col;
                c.data[k].row=b.data[i].row;
                k++;
                j++;
            }
            else{
                if(v!=0){
                v=a.data[i].num+b.data[i].num;
                c.data[k].row=a.data[i].row;
                c.data[k].col=a.data[i].col;
                c.data[k].num=v;
                k++;
                }
                i++;
                j++;
            }
        }
        else if(a.data[i].row<b.data[j].row){
            c.data[k].row=a.data[i].row;
            c.data[k].col=a.data[i].col;
            c.data[k].num=a.data[i].num;
            k++;
            i++;
        }
        else{
            c.data[k].row=b.data[j].row;
            c.data[k].col=b.data[j].col;
            c.data[k].num=b.data[j].num;
            k++;
            j++;
        }
        c.count=k;
    }
        return true;
}


int getvalue(TSMatrix t,int i,int j){
    int k=0;
    while(k<t.count&&(t.data[k].row!=i||t.data[k].col!=j)){
        k++;
    }
    if(k<t.count){
        return (t.data[k].num);
    }
    else
    return 0;
}

bool mulmat(TSMatrix a,TSMatrix b,TSMatrix &c){
    int i,j,k,p=0;
    Elemtype v;
    if(a.cols!=b.rows){
        return false;
    }
    for(int i=0;i<a.rows;i++){
        for(j=0;j<b.cols;j++){
            v=0;
            for(k=0;k<a.cols;k++){
            v=v+getvalue(a,i,k)*getvalue(b,k,j);
           if(p!=0){
            c.data[p].row=i;
            c.data[p].col=j;
            c.data[p].num=v;
            p++;
           }
           
            }
        }
    }
    c.cols=b.cols;
    c.rows=a.rows;
    c.count=p;
    return true;
}

void displayMAT(TSMatrix t){
    if(t.count<=0)
    return;
printf("\t%d\t%d\t%d\n",t.rows,t.cols,t.count);
printf("\t----------------\n");
for(int i=0;i<t.count;i++){
    printf("\t%d\t%d\t%d\n",t.data[i].row,t.data[i].col,t.data[i].num);

}
}

int main(){
    Elemtype A[N][N]={{1,0,3,0},{0,1,0,0},{0,0,1,0},{0,0,1,1}};
    Elemtype B[N][N]={{3,0,0,0},{0,4,0,0},{0,0,1,0},{0,0,0,2}};
    TSMatrix a,b,c;
    createmat(a,A);
    createmat(b,B);
    printf("a����Ԫ��:\n");displayMAT(a);
printf("b����Ԫ��:\n");displayMAT(b);
printf("aת��Ϊc\n");
transmat(a,c);
printf("c����Ԫ��:\n");displayMAT(c);
printf("c=a+b\n");
addmat(a,b,c);
printf("c����Ԫ��:\n");displayMAT(c);
printf("c=a��b\n");
mulmat(a,b,c);
printf("c����Ԫ��:\n");displayMAT(c);
return 1;
}
